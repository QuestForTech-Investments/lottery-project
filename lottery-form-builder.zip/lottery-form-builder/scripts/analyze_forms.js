#!/usr/bin/env node
/**
 * Playwright script to analyze existing forms in the lottery app
 * Usage: node analyze_forms.js <form-url> <output-file>
 *
 * Example:
 * node analyze_forms.js http://localhost:4200/bancas/lista analysis.json
 */

const { chromium } = require('playwright');
const fs = require('fs');

async function analyzeForm(url, outputFile) {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  try {
    console.log(`📊 Analyzing form at: ${url}`);
    await page.goto(url, { waitUntil: 'networkidle' });

    // Extract form structure
    const formAnalysis = await page.evaluate(() => {
      const analysis = {
        title: {},
        buttons: [],
        inputs: [],
        filters: [],
        tables: [],
        tabs: [],
        colors: [],
        fonts: []
      };

      // Analyze title
      const titleEl = document.querySelector('h1, h2, h3, .page-title, .card-header h1, .card-header h2, .card-header h3');
      if (titleEl) {
        const styles = window.getComputedStyle(titleEl);
        analysis.title = {
          text: titleEl.textContent.trim(),
          fontSize: styles.fontSize,
          fontWeight: styles.fontWeight,
          fontFamily: styles.fontFamily,
          color: styles.color,
          backgroundColor: styles.backgroundColor,
          textAlign: styles.textAlign,
          padding: styles.padding
        };
      }

      // Analyze buttons
      document.querySelectorAll('button, .btn').forEach(btn => {
        const styles = window.getComputedStyle(btn);
        analysis.buttons.push({
          text: btn.textContent.trim(),
          className: btn.className,
          backgroundColor: styles.backgroundColor,
          color: styles.color,
          fontSize: styles.fontSize,
          padding: styles.padding,
          borderRadius: styles.borderRadius
        });
      });

      // Analyze inputs
      document.querySelectorAll('input, select, textarea').forEach(input => {
        const styles = window.getComputedStyle(input);
        analysis.inputs.push({
          type: input.type || input.tagName.toLowerCase(),
          placeholder: input.placeholder,
          height: styles.height,
          fontSize: styles.fontSize,
          fontFamily: styles.fontFamily,
          border: styles.border,
          borderRadius: styles.borderRadius,
          padding: styles.padding
        });
      });

      // Analyze tables
      document.querySelectorAll('table').forEach(table => {
        const headers = Array.from(table.querySelectorAll('th')).map(th => ({
          text: th.textContent.trim(),
          styles: window.getComputedStyle(th)
        }));

        analysis.tables.push({
          columnCount: headers.length,
          headers: headers.map(h => h.text),
          headerStyles: headers.length > 0 ? {
            backgroundColor: headers[0].styles.backgroundColor,
            color: headers[0].styles.color,
            fontWeight: headers[0].styles.fontWeight,
            fontSize: headers[0].styles.fontSize
          } : {}
        });
      });

      // Extract unique colors used
      const allElements = document.querySelectorAll('*');
      const colorSet = new Set();
      allElements.forEach(el => {
        const styles = window.getComputedStyle(el);
        if (styles.backgroundColor && styles.backgroundColor !== 'rgba(0, 0, 0, 0)') {
          colorSet.add(styles.backgroundColor);
        }
        if (styles.color) {
          colorSet.add(styles.color);
        }
      });
      analysis.colors = Array.from(colorSet);

      // Extract font families
      const fontSet = new Set();
      allElements.forEach(el => {
        const styles = window.getComputedStyle(el);
        if (styles.fontFamily) {
          fontSet.add(styles.fontFamily);
        }
      });
      analysis.fonts = Array.from(fontSet);

      return analysis;
    });

    // Take screenshot
    const screenshotPath = outputFile.replace('.json', '.png');
    await page.screenshot({ path: screenshotPath, fullPage: true });
    console.log(`📸 Screenshot saved: ${screenshotPath}`);

    // Save analysis
    fs.writeFileSync(outputFile, JSON.stringify(formAnalysis, null, 2));
    console.log(`✅ Analysis saved: ${outputFile}`);

    // Print summary
    console.log('\n📋 Summary:');
    console.log(`   Title: ${formAnalysis.title.text || 'N/A'}`);
    console.log(`   Buttons: ${formAnalysis.buttons.length}`);
    console.log(`   Inputs: ${formAnalysis.inputs.length}`);
    console.log(`   Tables: ${formAnalysis.tables.length}`);
    console.log(`   Unique Colors: ${formAnalysis.colors.length}`);
    console.log(`   Font Families: ${formAnalysis.fonts.length}`);

  } catch (error) {
    console.error('❌ Error analyzing form:', error);
    throw error;
  } finally {
    await browser.close();
  }
}

// Main
const args = process.argv.slice(2);
if (args.length < 2) {
  console.error('Usage: node analyze_forms.js <form-url> <output-file>');
  console.error('Example: node analyze_forms.js http://localhost:4200/bancas/lista analysis.json');
  process.exit(1);
}

const [url, outputFile] = args;
analyzeForm(url, outputFile).catch(error => {
  console.error('Failed to analyze form:', error);
  process.exit(1);
});
