---
name: lottery-form-builder
description: Create new forms in the lottery application that maintain design coherence with existing forms. Use this skill when the user requests creating a new list view, CRUD form, or data management interface for the lottery system. Automatically analyzes existing forms using Playwright, applies the design system rules, and generates code following project conventions (English names, Spanish UI text, Montserrat font, turquoise/green colors).
---

# Lottery Form Builder

Create new forms and list views for the lottery application that automatically maintain design coherence with existing forms.

## When to Use This Skill

Use this skill when the user requests:

- Creating a new list view (e.g., "Create a users list form", "Build a zones management page")
- Adding CRUD interfaces (Create, Read, Update, Delete forms)
- Building data management screens with tables and filters
- Adding new sections to the lottery admin panel

**Trigger phrases:** "create form", "build list", "new management page", "add CRUD interface"

## Prerequisites

Before creating a form, verify:

1. **Project context loaded**: Read `/home/jorge/projects/lottery-project/CLAUDE.md`
2. **Design system available**: Reference `/home/jorge/projects/lottery-project/DESIGN_SYSTEM.md`
3. **Frontend running**: V1 on port 4200 or V2 on port 4000
4. **Playwright available**: For analyzing existing forms

## Form Creation Process

Follow this process for EVERY new form to ensure coherence:

### Step 1: Analyze Similar Existing Forms

Before writing ANY code, use Playwright to analyze 2-3 similar existing forms to identify patterns.

**Script:** `scripts/analyze_forms.js`

**Usage:**
```bash
cd /home/jorge/.claude/skills/lottery-form-builder
node scripts/analyze_forms.js http://localhost:4200/bancas/lista analysis-bancas.json
node scripts/analyze_forms.js http://localhost:4200/balances/bancas analysis-balances.json
```

**This script captures:**
- Title styling (color, font, background)
- Button styles and colors
- Input field dimensions and styling
- Table structure and styling
- Color palette used
- Font families used

**Output:**
- JSON file with detailed analysis
- Screenshot (PNG) for visual reference

**Review the analysis** to identify:
- Common title pattern (should be: black text, transparent background, 24px, Montserrat, centered)
- Button colors (primary: #51cbce turquoise, success: #28a745 green)
- Input height (should be 40px)
- Table styling patterns
- Font usage (should be Montserrat)

### Step 2: Determine Entity and Translations

Identify the domain entity and establish naming:

**English (Code):**
- Component name: `BettingPoolsList`, `DrawsList`, `UsersList`
- File name: `BettingPoolsList.jsx`
- Variables: `bettingPools`, `selectedDraw`, `filterZones`
- API endpoint: `/api/betting-pools`, `/api/draws`

**Spanish (UI Text):**
- Page title: "Lista de bancas", "Lista de sorteos", "Lista de usuarios"
- Button text: "CREAR", "FILTRAR", "GUARDAR"
- Labels: "Zona", "Fecha", "Estado"

**Common Entity Translations:**
- Banca → BettingPool
- Sorteo → Draw
- Usuario → User
- Zona → Zone
- Premio → Prize
- Boleto/Ticket → Ticket
- Lotería → Lottery

### Step 3: Choose Template

Select the appropriate template based on frontend version:

**Frontend V1 (Bootstrap):**
- Template: `assets/bootstrap_form_template.jsx`
- Stack: React 18 + Vite + Bootstrap 5
- Port: 4200
- CSS: FormStyles.css + custom CSS

**Frontend V2 (Material-UI):**
- Template: `assets/mui_form_template.jsx` (if available)
- Stack: React 18 + Vite + MUI
- Port: 4000
- Theme: Custom MUI theme

### Step 4: Customize Template

Replace placeholders in the template:

1. **Entity Name**
   - Replace `ENTITY_NAME` with actual entity (e.g., `BettingPool`, `Draw`)
   - Example: `ENTITY_NAMEList` → `BettingPoolsList`

2. **API Endpoint**
   - Replace `/api/ENDPOINT` with actual endpoint
   - Example: `/api/betting-pools`, `/api/draws`

3. **Spanish UI Text**
   - Update page title: "Lista de bancas"
   - Update button labels: "CREAR NUEVA BANCA"
   - Update filter labels: "Zona", "Fecha", "Estado"

4. **Table Columns**
   - Define columns based on entity properties
   - Example for BettingPools: Número, Nombre, Referencia, Zona, Balance, Activa

5. **Filters**
   - Add relevant filters (date, zone, status, etc.)
   - Use standard filter components

6. **Actions**
   - Implement create, edit, delete handlers
   - Connect to API endpoints

### Step 5: Apply Design System Rules

**CRITICAL:** Verify these design rules are applied:

#### Title (MANDATORY)
```jsx
<h3 style={{
  color: '#2c2c2c',           // ✅ Black text
  background: 'transparent',   // ✅ NO background color
  fontSize: '24px',
  fontWeight: 600,
  textAlign: 'center',
  padding: '20px',
  fontFamily: 'Montserrat, "Helvetica Neue", Arial, sans-serif'
}}>
  {Spanish title text}
</h3>
```

**❌ NEVER use:**
- Colored backgrounds on titles (turquoise, purple, gradient)
- White text on colored background
- Different fonts (Arial only, no Montserrat)

#### Primary Button
```jsx
<button style={{
  backgroundColor: '#51cbce',  // ✅ Turquoise
  color: 'white',
  fontSize: '14px',
  fontWeight: 600,
  padding: '12px 24px',
  borderRadius: '6px',
  fontFamily: 'Montserrat, "Helvetica Neue", Arial, sans-serif'
}}>
  BUTTON TEXT
</button>
```

#### Success Button (Filter)
```jsx
<button style={{
  backgroundColor: '#28a745',  // ✅ Green
  color: 'white',
  fontSize: '14px',
  fontWeight: 600
}}>
  FILTRAR
</button>
```

#### Input Fields
```jsx
<input style={{
  height: '40px',              // ✅ Standard height
  fontSize: '14px',
  border: '1px solid #dee2e6',
  borderRadius: '4px',
  padding: '8px 12px',
  fontFamily: 'Montserrat, "Helvetica Neue", Arial, sans-serif'
}} />
```

#### Table Headers
```jsx
<thead style={{ backgroundColor: '#f8f9fa' }}>
  <tr>
    <th style={{
      padding: '15px 12px',
      fontWeight: 700,
      fontSize: '14px',
      color: '#2c2c2c',
      borderBottom: '2px solid #dee2e6'
    }}>
      Column Name
    </th>
  </tr>
</thead>
```

**Reference:** See `references/form_patterns.md` for complete pattern library

### Step 6: Verify Design Coherence

After creating the form, verify it matches existing forms:

#### Manual Verification with Playwright
```bash
# Take screenshots of new form and existing forms
node scripts/analyze_forms.js http://localhost:4200/your-new-form new-form-analysis.json

# Compare visually:
# - Title should have same styling as other forms (black text, no background)
# - Buttons should use same colors (#51cbce, #28a745)
# - Inputs should have same height (40px)
# - Tables should have same header/row styling
```

#### Automated Verification
```bash
cd /home/jorge/projects/lottery-project

# Check for unauthorized colors
./scripts/check-design-consistency.sh

# Check for Spanish naming
./scripts/verify-naming.sh
```

**Fix any warnings before proceeding.**

### Step 7: Test the Form EXHAUSTIVELY

**CRITICAL:** The form must be tested exhaustively and work EXACTLY like the original before considering it complete. No partial implementations are acceptable.

#### A. Menu Navigation Testing (MANDATORY)

**Before ANY functional testing, verify navigation:**

1. **Route Connection**
   ```bash
   # Verify route exists in App.jsx
   grep -n "your-route-path" frontend-v1/src/App.jsx
   grep -n "your-route-path" frontend-v2/src/App.jsx
   ```

2. **Menu Connection**
   ```bash
   # Verify menu item points to correct route
   grep -n "your-route-path" frontend-v1/src/constants/menuItems.js
   grep -n "your-route-path" frontend-v2/src/constants/menuItems.js
   ```

3. **Manual Navigation Test**
   - Start frontend: `npm run dev`
   - Click on menu item
   - **VERIFY:** Component loads (not blank page)
   - **VERIFY:** URL matches expected route
   - **VERIFY:** No console errors

**If navigation fails, STOP and fix before continuing with other tests.**

#### B. Functional Testing (Compare with Original)

If migrating from Vue.js app, test side-by-side with original:

**Original Vue.js App:** https://la-numbers.apk.lol (user: oliver, password: oliver0597@)

**Testing Checklist:**

1. **Data Loading**
   - [ ] Initial data loads automatically
   - [ ] Loading spinner shows during fetch
   - [ ] Data displays in correct format
   - [ ] Empty state shows when no data
   - [ ] Error handling works (test with network offline)

2. **Filters - Test EVERY Filter**
   - [ ] Date filter: Changes data when date changes
   - [ ] Zone filter: Shows correct data per zone
   - [ ] Status filter: TODOS/ACTIVOS/INACTIVOS all work
   - [ ] Multiple filters combined work correctly
   - [ ] "LIMPIAR" button resets all filters
   - [ ] "FILTRAR" button refreshes data
   - [ ] Filter state persists during session

3. **Table Functionality**
   - [ ] Correct number of columns
   - [ ] Column headers match original
   - [ ] Data types formatted correctly (dates, currency, numbers)
   - [ ] Sorting works (if applicable)
   - [ ] Row hover effect works
   - [ ] Click on row works (if applicable)
   - [ ] Pagination shows correct page numbers
   - [ ] Items per page selector works
   - [ ] Navigate between pages works

4. **Actions - Test EVERY Action Button**
   - [ ] "CREAR" button opens create form/modal
   - [ ] "EDITAR" (edit icon) opens edit form with correct data
   - [ ] "ELIMINAR" (delete icon) shows confirmation dialog
   - [ ] Delete actually removes item from list
   - [ ] Export/Print buttons work (if applicable)
   - [ ] Success/error messages show after actions
   - [ ] Table refreshes after create/edit/delete

5. **API Integration**
   - [ ] Correct API endpoints called (check Network tab)
   - [ ] Request payloads match API expectations
   - [ ] Response data parsed correctly
   - [ ] Authentication headers included
   - [ ] Error responses handled gracefully
   - [ ] No unnecessary duplicate API calls

6. **Responsiveness**
   - [ ] Desktop (1920x1080): All elements visible
   - [ ] Laptop (1366x768): No horizontal scroll
   - [ ] Tablet (768px): Filters stack vertically
   - [ ] Mobile (375px): Table scrolls horizontally

7. **Edge Cases**
   - [ ] Empty data array: Shows "No se encontraron resultados"
   - [ ] Very long text in cells: Truncates or wraps
   - [ ] Special characters in data: Display correctly
   - [ ] Large datasets (1000+ items): Pagination works

#### C. Side-by-Side Comparison (If Migrating)

**Use Playwright to compare:**

```javascript
// Test original Vue.js app
const originalPage = await browser.newPage();
await originalPage.goto('https://la-numbers.apk.lol/#/your-original-route');
await originalPage.screenshot({ path: 'original.png' });

// Test new React component
const newPage = await browser.newPage();
await newPage.goto('http://localhost:4200/your-new-route');
await newPage.screenshot({ path: 'new.png' });

// Compare visually and functionally
```

**Verify:**
- [ ] Same number of filters
- [ ] Same table columns
- [ ] Same action buttons
- [ ] Same functionality (create, edit, delete)
- [ ] Same data displayed
- [ ] Similar visual appearance (colors may vary per design system)

#### D. Integration Testing

1. **Menu Navigation**
   - [ ] Can navigate TO this form from menu
   - [ ] Can navigate AWAY from this form to other sections
   - [ ] Browser back button works
   - [ ] Direct URL access works

2. **State Management**
   - [ ] Filter state doesn't affect other pages
   - [ ] Refreshing page preserves filters (if required)
   - [ ] Logged out user redirected to login

3. **Performance**
   - [ ] Initial load < 2 seconds
   - [ ] Filter operation < 500ms
   - [ ] No memory leaks (check DevTools Performance)
   - [ ] No console errors or warnings

#### E. User Acceptance Testing

**Before delivery, verify with user:**

1. Open both V1 and V2 implementations
2. Navigate from menu (user clicks, not direct URL)
3. Test main workflows user will perform
4. Get explicit confirmation: "This works exactly like I need it to"

**Do NOT consider the form complete until:**
- ✅ User can access it from menu
- ✅ All functionality works identically to original
- ✅ No console errors
- ✅ User explicitly confirms it works

## Common Patterns

### Date Filter
```jsx
<input
  type="date"
  value={filters.date}
  onChange={(e) => handleFilterChange('date', e.target.value)}
  style={{ height: '40px', fontSize: '14px' }}
/>
```

### Zone Multi-Select
```jsx
<select
  multiple
  value={filters.zones}
  onChange={(e) => handleFilterChange('zones', Array.from(e.target.selectedOptions, o => o.value))}
  style={{ height: '120px', fontSize: '14px' }}
>
  {zones.map(zone => (
    <option key={zone.id} value={zone.id}>{zone.name}</option>
  ))}
</select>
```

### Status Radio Buttons
```jsx
<div className="btn-group" role="group">
  <button
    className={filters.status === 'all' ? 'btn btn-info' : 'btn btn-outline-secondary'}
    onClick={() => handleFilterChange('status', 'all')}
  >
    TODOS
  </button>
  <button
    className={filters.status === 'active' ? 'btn btn-info' : 'btn btn-outline-secondary'}
    onClick={() => handleFilterChange('status', 'active')}
  >
    ACTIVOS
  </button>
  <button
    className={filters.status === 'inactive' ? 'btn btn-info' : 'btn btn-outline-secondary'}
    onClick={() => handleFilterChange('status', 'inactive')}
  >
    INACTIVOS
  </button>
</div>
```

### Action Buttons in Table
```jsx
<button
  onClick={() => handleEdit(item.id)}
  className="btn btn-sm btn-info"
  style={{ fontSize: '12px', marginRight: '5px' }}
>
  <i className="fa fa-edit"></i>
</button>
<button
  onClick={() => handleDelete(item.id)}
  className="btn btn-sm btn-danger"
  style={{ fontSize: '12px' }}
>
  <i className="fa fa-trash"></i>
</button>
```

## Reusable Components

Import and use these existing shared components:

1. **Pagination**: `frontend-v1/src/components/shared/Pagination.jsx`
   ```jsx
   import Pagination from '../shared/Pagination';

   <Pagination
     currentPage={pagination.currentPage}
     totalPages={Math.ceil(pagination.totalItems / pagination.pageSize)}
     onPageChange={(page) => setPagination(prev => ({ ...prev, currentPage: page }))}
   />
   ```

2. **TimePicker**: `frontend-v1/src/components/shared/TimePicker.jsx`

3. **Toggle Buttons**: `frontend-v1/src/components/common/form/ToggleButtonGroup.jsx`

4. **Selectable Badges**: `frontend-v1/src/components/common/form/SelectableBadgeGroup.jsx`

## Troubleshooting

### Title has colored background
**Fix:** Remove background color, use `background: 'transparent'`, change text color to `#2c2c2c`

### Buttons wrong color
**Fix:** Primary buttons use `#51cbce`, success/filter buttons use `#28a745`

### Wrong font
**Fix:** All text should use `Montserrat, "Helvetica Neue", Arial, sans-serif`

### Input fields wrong height
**Fix:** All inputs should have `height: '40px'`

### Spanish names in code
**Fix:** Rename components/variables to English (Banca → BettingPool, Sorteo → Draw)

### Form looks different from others
**Fix:** Run `scripts/analyze_forms.js` on existing forms, compare patterns, adjust styling

## Files Reference

- **Form Patterns**: `references/form_patterns.md` - Complete pattern library
- **Bootstrap Template**: `assets/bootstrap_form_template.jsx` - Ready-to-use template
- **Analysis Script**: `scripts/analyze_forms.js` - Playwright form analyzer
- **Design System**: `/home/jorge/projects/lottery-project/DESIGN_SYSTEM.md`
- **Project Context**: `/home/jorge/projects/lottery-project/CLAUDE.md`

## Quality Checklist

**CRITICAL:** A form is NOT complete until ALL items are checked. No partial implementations.

### Design & Code Quality

- [ ] Analyzed 2-3 similar existing forms with Playwright
- [ ] Title has black text (#2c2c2c) and transparent background
- [ ] Primary buttons use turquoise (#51cbce)
- [ ] Filter buttons use green (#28a745)
- [ ] All text uses Montserrat font
- [ ] Input fields are 40px height
- [ ] Table headers have correct styling (#f8f9fa background)
- [ ] All code names in English (components, variables, files)
- [ ] All UI text in Spanish (titles, buttons, labels)
- [ ] No Spanish words in component/variable names
- [ ] Ran `./scripts/check-design-consistency.sh` with no warnings
- [ ] Ran `./scripts/verify-naming.sh` with no errors
- [ ] Form matches visual coherence of existing forms

### Navigation & Integration

- [ ] Route added to `App.jsx` in both V1 and V2
- [ ] Menu item added to `menuItems.js` in both V1 and V2
- [ ] Menu item path matches route in `App.jsx`
- [ ] Component loads when clicking menu item (not blank page)
- [ ] No console errors when navigating to form
- [ ] Can navigate TO form from other sections
- [ ] Can navigate AWAY from form to other sections
- [ ] Browser back button works correctly

### Functional Testing

- [ ] Initial data loads automatically without errors
- [ ] Loading spinner shows during API calls
- [ ] Empty state displays correctly when no data
- [ ] ALL filters work correctly (date, zone, status, etc.)
- [ ] "FILTRAR" button refreshes data
- [ ] "LIMPIAR" button resets all filters
- [ ] Table displays correct columns with correct headers
- [ ] Table data formatted correctly (dates, currency, numbers)
- [ ] Pagination works (page numbers, items per page)
- [ ] "CREAR" button works (opens form/modal)
- [ ] "EDITAR" button works (loads correct data)
- [ ] "ELIMINAR" button works (shows confirmation, actually deletes)
- [ ] Table refreshes after create/edit/delete actions
- [ ] Success/error messages display correctly

### API Integration

- [ ] Correct API endpoints called (verified in Network tab)
- [ ] Request payloads match API expectations
- [ ] Response data parsed and displayed correctly
- [ ] Authentication headers included in requests
- [ ] Error responses handled gracefully (no crashes)
- [ ] No unnecessary duplicate API calls

### Comparison with Original (If Migrating)

- [ ] Opened original Vue.js app at https://la-numbers.apk.lol
- [ ] Compared side-by-side with React implementation
- [ ] Same number of filters
- [ ] Same table columns
- [ ] Same action buttons
- [ ] Same functionality works identically
- [ ] Same data displayed in same format

### Responsive & Edge Cases

- [ ] Tested on desktop (1920x1080)
- [ ] Tested on laptop (1366x768)
- [ ] Tested on tablet (768px)
- [ ] Tested on mobile (375px)
- [ ] Empty data shows proper message
- [ ] Long text in cells handled correctly
- [ ] Special characters display correctly
- [ ] Large datasets (1000+ items) work with pagination

### User Acceptance

- [ ] User tested navigation from menu
- [ ] User tested main workflows
- [ ] User confirmed: "This works exactly like I need it to"
- [ ] No outstanding bugs or issues
- [ ] User explicitly approved for production

**ONLY mark as complete when:**
✅ ALL checkboxes above are checked
✅ No console errors
✅ Works identically to original
✅ User has explicitly approved
