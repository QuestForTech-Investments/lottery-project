# Form Patterns Reference

This document describes common patterns found in lottery app forms based on analysis of existing forms.

## Standard Form Structure

All forms in the lottery app follow this structure:

```
┌─────────────────────────────────────────┐
│ PAGE TITLE (h3)                         │
│ - Color: #2c2c2c (black text)           │
│ - Background: transparent               │
│ - Font: Montserrat, 24px, weight 600    │
│ - Alignment: center                     │
│ - Padding: 20px                         │
├─────────────────────────────────────────┤
│ FILTERS SECTION                         │
│ - Date pickers                          │
│ - Zone selectors                        │
│ - Status filters                        │
│ - Buttons: FILTRAR (green), LIMPIAR    │
├─────────────────────────────────────────┤
│ ACTION BUTTONS                          │
│ - CREAR/NUEVO (turquoise #51cbce)      │
│ - EXPORTAR                              │
│ - IMPRIMIR                              │
├─────────────────────────────────────────┤
│ DATA TABLE                              │
│ - Headers: #f8f9fa background          │
│ - Rows: alternating white/#f8f9fa      │
│ - Hover: #f8f9fa                        │
│ - Border: #dee2e6                       │
├─────────────────────────────────────────┤
│ PAGINATION                              │
│ - Items per page selector              │
│ - Page numbers                          │
│ - Previous/Next buttons                 │
└─────────────────────────────────────────┘
```

## Title Patterns

### ✅ CORRECT Pattern
```jsx
<div className="page-title">
  <h3 style={{
    color: '#2c2c2c',
    background: 'transparent',
    fontSize: '24px',
    fontWeight: 600,
    textAlign: 'center',
    padding: '20px',
    fontFamily: 'Montserrat, "Helvetica Neue", Arial, sans-serif'
  }}>
    {title text in Spanish}
  </h3>
</div>
```

### ❌ INCORRECT Patterns
```jsx
// Don't use colored backgrounds
<h3 style={{ background: '#51cbce' }}>Title</h3>
<h3 style={{ background: 'linear-gradient(...)' }}>Title</h3>

// Don't use white text
<h3 style={{ color: 'white' }}>Title</h3>
```

## Button Patterns

### Primary Button (Turquoise)
```jsx
<button
  className="btn btn-info"
  style={{
    backgroundColor: '#51cbce',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    padding: '12px 24px',
    fontSize: '14px',
    fontWeight: 600,
    fontFamily: 'Montserrat, "Helvetica Neue", Arial, sans-serif'
  }}
>
  BUTTON TEXT
</button>
```

### Success Button (Green)
```jsx
<button
  className="btn btn-success"
  style={{
    backgroundColor: '#28a745',
    color: 'white',
    fontSize: '14px',
    fontWeight: 600
  }}
>
  FILTRAR
</button>
```

### Secondary/Outline Button
```jsx
<button className="btn btn-outline-secondary">
  LIMPIAR
</button>
```

## Input Patterns

### Text Input
```jsx
<input
  type="text"
  className="form-control"
  style={{
    height: '40px',
    padding: '8px 12px',
    border: '1px solid #dee2e6',
    borderRadius: '4px',
    fontSize: '14px',
    fontFamily: 'Montserrat, "Helvetica Neue", Arial, sans-serif'
  }}
  placeholder="Placeholder text"
/>
```

### Select/Dropdown
```jsx
<select
  className="form-control"
  style={{
    height: '40px',
    fontSize: '14px',
    border: '1px solid #dee2e6',
    borderRadius: '4px'
  }}
>
  <option value="">Seleccionar...</option>
  {/* options */}
</select>
```

## Table Patterns

### Table Structure
```jsx
<table className="table table-striped table-hover">
  <thead style={{ backgroundColor: '#f8f9fa' }}>
    <tr>
      <th style={{
        padding: '15px 12px',
        fontWeight: 700,
        fontSize: '14px',
        color: '#2c2c2c',
        borderBottom: '2px solid #dee2e6'
      }}>
        Column Name
      </th>
    </tr>
  </thead>
  <tbody>
    <tr style={{ cursor: 'pointer' }}>
      <td style={{
        padding: '12px',
        fontSize: '14px',
        borderBottom: '1px solid #dee2e6'
      }}>
        Cell Content
      </td>
    </tr>
  </tbody>
</table>
```

### Table CSS Classes
- `table` - Base table
- `table-striped` - Alternating row colors
- `table-hover` - Hover effect
- `table-responsive` - Responsive wrapper

## Filter Section Patterns

### Standard Filter Layout
```jsx
<div className="filters-section" style={{
  backgroundColor: 'white',
  padding: '20px',
  marginBottom: '20px',
  borderRadius: '6px',
  boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
}}>
  <div className="row">
    <div className="col-md-3">
      <label style={{ fontSize: '12px', color: '#787878' }}>
        Filter Label
      </label>
      <input type="date" className="form-control" />
    </div>
    {/* More filter columns */}
  </div>
  <div className="row mt-3">
    <div className="col-md-12 text-right">
      <button className="btn btn-success mr-2">FILTRAR</button>
      <button className="btn btn-outline-secondary">LIMPIAR</button>
    </div>
  </div>
</div>
```

## Form Labels

### Label Pattern
```jsx
<label style={{
  fontSize: '12px',
  color: 'rgb(120, 120, 120)',
  fontWeight: 400,
  marginBottom: '5px',
  display: 'block',
  fontFamily: 'Montserrat, "Helvetica Neue", Arial, sans-serif'
}}>
  Label Text
</label>
```

## Spacing System

Use these spacing values consistently:

- **4px** (`--spacing-xs`): Badge padding, minimal gaps
- **8px** (`--spacing-sm`): Input padding, small gaps
- **12px**: Table cell padding
- **16px** (`--spacing-md`): Card padding, section gaps
- **20px**: Page title padding, filter section padding
- **24px** (`--spacing-lg`): Container padding

## Color Usage

### Primary Colors
- **#51cbce** - Primary buttons, active states, icons
- **#28a745** - Success buttons (FILTRAR), success messages
- **#2c2c2c** - Text color (headings, labels, body)
- **#787878** - Secondary text (labels, hints)

### Background Colors
- **#ffffff** - Cards, tables, inputs
- **#f5f5f5** - Page background
- **#f8f9fa** - Table headers, alternating rows, hover states

### Border Colors
- **#dee2e6** - Standard borders (inputs, table cells)
- **#e8e8e8** - Subtle borders

## Responsive Breakpoints

```css
/* Mobile First */
@media (min-width: 576px) { /* Phones landscape */ }
@media (min-width: 768px) { /* Tablets */ }
@media (min-width: 992px) { /* Laptops */ }
@media (min-width: 1200px) { /* Desktops */ }
```

## Common Components to Reuse

1. **Pagination** - `frontend-v1/src/components/shared/Pagination.jsx`
2. **DatePicker** - Standard HTML5 date input
3. **TimePicker** - `frontend-v1/src/components/shared/TimePicker.jsx`
4. **Toggle Buttons** - `frontend-v1/src/components/common/form/ToggleButtonGroup.jsx`
5. **Badges** - `frontend-v1/src/components/common/form/SelectableBadgeGroup.jsx`

## Naming Conventions

### Component Names (English)
- ✅ `BettingPoolsList`, `CreateBettingPool`, `EditBettingPool`
- ✅ `DrawsList`, `CreateDraw`, `EditDraw`
- ❌ `ListaBancas`, `CrearBanca`, `EditarBanca`

### File Names (English)
- ✅ `BettingPoolsList.jsx`, `CreateBettingPool.jsx`
- ❌ `ListaBancas.jsx`, `CrearBanca.jsx`

### CSS Classes (kebab-case, English)
- ✅ `betting-pool-card`, `draw-list-container`
- ❌ `banca-card`, `lista-sorteos`

### Variable Names (camelCase, English)
- ✅ `bettingPools`, `selectedDraw`, `filterZones`
- ❌ `bancas`, `sorteoSeleccionado`, `filtroZonas`

### UI Text (Spanish)
- ✅ Button text: "CREAR BANCA", "FILTRAR", "GUARDAR"
- ✅ Labels: "Zona", "Fecha", "Estado"
- ✅ Titles: "Lista de bancas", "Crear nueva banca"
