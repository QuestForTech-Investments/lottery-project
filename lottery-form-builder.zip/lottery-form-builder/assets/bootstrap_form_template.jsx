import React, { useState, useEffect } from 'react';
import '../assets/css/FormStyles.css';

/**
 * Template for Bootstrap-based forms in Frontend V1
 *
 * INSTRUCTIONS:
 * 1. Replace ENTITY_NAME with your entity (e.g., BettingPool, Draw, User)
 * 2. Update API_ENDPOINT with actual endpoint
 * 3. Customize filters, columns, and actions as needed
 * 4. Ensure all names are in ENGLISH (variables, functions, files)
 * 5. Keep UI text in SPANISH (buttons, labels, titles)
 */

const ENTITY_NAMEList = () => {
  // State
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    date: new Date().toISOString().split('T')[0],
    zone: '',
    status: 'all'
  });
  const [pagination, setPagination] = useState({
    currentPage: 1,
    pageSize: 10,
    totalItems: 0
  });

  // Load data
  useEffect(() => {
    loadData();
  }, [filters, pagination.currentPage]);

  const loadData = async () => {
    setLoading(true);
    try {
      // TODO: Replace with actual API call
      const response = await fetch('/api/ENDPOINT');
      const data = await response.json();
      setItems(data.items || data);
      setPagination(prev => ({ ...prev, totalItems: data.totalCount || data.length }));
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Handlers
  const handleFilterChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
    setPagination(prev => ({ ...prev, currentPage: 1 })); // Reset to page 1
  };

  const handleClearFilters = () => {
    setFilters({
      date: new Date().toISOString().split('T')[0],
      zone: '',
      status: 'all'
    });
  };

  const handleCreate = () => {
    // TODO: Navigate to create page
    console.log('Navigate to create');
  };

  const handleEdit = (id) => {
    // TODO: Navigate to edit page
    console.log('Edit item:', id);
  };

  const handleDelete = async (id) => {
    if (!confirm('¿Está seguro de eliminar este elemento?')) return;

    try {
      // TODO: Delete API call
      await fetch(`/api/ENDPOINT/${id}`, { method: 'DELETE' });
      loadData();
    } catch (error) {
      console.error('Error deleting:', error);
    }
  };

  return (
    <div className="container-fluid" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh', padding: '20px' }}>
      {/* Page Title - BLACK TEXT, NO BACKGROUND COLOR */}
      <div className="page-title">
        <h3 style={{
          color: '#2c2c2c',
          background: 'transparent',
          fontSize: '24px',
          fontWeight: 600,
          textAlign: 'center',
          padding: '20px',
          margin: 0,
          fontFamily: 'Montserrat, "Helvetica Neue", Arial, sans-serif'
        }}>
          Lista de {/* TODO: Spanish title */}
        </h3>
      </div>

      {/* Filters Section */}
      <div className="card mb-3" style={{ border: 'none', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
        <div className="card-body">
          <div className="row">
            {/* Date Filter */}
            <div className="col-md-3 mb-3">
              <label style={{ fontSize: '12px', color: '#787878', marginBottom: '5px' }}>
                Fecha
              </label>
              <input
                type="date"
                className="form-control"
                value={filters.date}
                onChange={(e) => handleFilterChange('date', e.target.value)}
                style={{
                  height: '40px',
                  fontSize: '14px',
                  border: '1px solid #dee2e6',
                  borderRadius: '4px'
                }}
              />
            </div>

            {/* Zone Filter */}
            <div className="col-md-3 mb-3">
              <label style={{ fontSize: '12px', color: '#787878', marginBottom: '5px' }}>
                Zona
              </label>
              <select
                className="form-control"
                value={filters.zone}
                onChange={(e) => handleFilterChange('zone', e.target.value)}
                style={{
                  height: '40px',
                  fontSize: '14px',
                  border: '1px solid #dee2e6',
                  borderRadius: '4px'
                }}
              >
                <option value="">Todas las zonas</option>
                {/* TODO: Add zone options */}
              </select>
            </div>

            {/* Status Filter */}
            <div className="col-md-3 mb-3">
              <label style={{ fontSize: '12px', color: '#787878', marginBottom: '5px' }}>
                Estado
              </label>
              <select
                className="form-control"
                value={filters.status}
                onChange={(e) => handleFilterChange('status', e.target.value)}
                style={{
                  height: '40px',
                  fontSize: '14px',
                  border: '1px solid #dee2e6',
                  borderRadius: '4px'
                }}
              >
                <option value="all">Todos</option>
                <option value="active">Activos</option>
                <option value="inactive">Inactivos</option>
              </select>
            </div>

            {/* Filter Buttons */}
            <div className="col-md-3 mb-3 d-flex align-items-end">
              <button
                onClick={loadData}
                className="btn btn-success mr-2"
                style={{
                  backgroundColor: '#28a745',
                  border: 'none',
                  fontSize: '14px',
                  fontWeight: 600,
                  padding: '10px 20px'
                }}
              >
                FILTRAR
              </button>
              <button
                onClick={handleClearFilters}
                className="btn btn-outline-secondary"
                style={{ fontSize: '14px', padding: '10px 20px' }}
              >
                LIMPIAR
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mb-3">
        <button
          onClick={handleCreate}
          className="btn btn-info"
          style={{
            backgroundColor: '#51cbce',
            border: 'none',
            color: 'white',
            fontSize: '14px',
            fontWeight: 600,
            padding: '12px 24px',
            borderRadius: '6px'
          }}
        >
          CREAR NUEVO
        </button>
      </div>

      {/* Data Table */}
      <div className="card" style={{ border: 'none', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
        <div className="card-body p-0">
          {loading ? (
            <div className="text-center p-4">
              <div className="spinner-border text-info" role="status">
                <span className="sr-only">Cargando...</span>
              </div>
            </div>
          ) : (
            <div className="table-responsive">
              <table className="table table-striped table-hover mb-0">
                <thead style={{ backgroundColor: '#f8f9fa' }}>
                  <tr>
                    <th style={{
                      padding: '15px 12px',
                      fontWeight: 700,
                      fontSize: '14px',
                      color: '#2c2c2c',
                      borderBottom: '2px solid #dee2e6'
                    }}>
                      ID
                    </th>
                    <th style={{
                      padding: '15px 12px',
                      fontWeight: 700,
                      fontSize: '14px',
                      color: '#2c2c2c',
                      borderBottom: '2px solid #dee2e6'
                    }}>
                      Nombre
                    </th>
                    <th style={{
                      padding: '15px 12px',
                      fontWeight: 700,
                      fontSize: '14px',
                      color: '#2c2c2c',
                      borderBottom: '2px solid #dee2e6'
                    }}>
                      Zona
                    </th>
                    <th style={{
                      padding: '15px 12px',
                      fontWeight: 700,
                      fontSize: '14px',
                      color: '#2c2c2c',
                      borderBottom: '2px solid #dee2e6'
                    }}>
                      Estado
                    </th>
                    <th style={{
                      padding: '15px 12px',
                      fontWeight: 700,
                      fontSize: '14px',
                      color: '#2c2c2c',
                      borderBottom: '2px solid #dee2e6'
                    }}>
                      Acciones
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {items.length === 0 ? (
                    <tr>
                      <td colSpan="5" className="text-center p-4" style={{ fontSize: '14px', color: '#787878' }}>
                        No se encontraron resultados
                      </td>
                    </tr>
                  ) : (
                    items.map(item => (
                      <tr key={item.id} style={{ cursor: 'pointer' }}>
                        <td style={{
                          padding: '12px',
                          fontSize: '14px',
                          borderBottom: '1px solid #dee2e6'
                        }}>
                          {item.id}
                        </td>
                        <td style={{
                          padding: '12px',
                          fontSize: '14px',
                          borderBottom: '1px solid #dee2e6'
                        }}>
                          {item.name}
                        </td>
                        <td style={{
                          padding: '12px',
                          fontSize: '14px',
                          borderBottom: '1px solid #dee2e6'
                        }}>
                          {item.zone}
                        </td>
                        <td style={{
                          padding: '12px',
                          fontSize: '14px',
                          borderBottom: '1px solid #dee2e6'
                        }}>
                          <span className={`badge badge-${item.active ? 'success' : 'secondary'}`}>
                            {item.active ? 'Activo' : 'Inactivo'}
                          </span>
                        </td>
                        <td style={{
                          padding: '12px',
                          fontSize: '14px',
                          borderBottom: '1px solid #dee2e6'
                        }}>
                          <button
                            onClick={() => handleEdit(item.id)}
                            className="btn btn-sm btn-info mr-2"
                            style={{ fontSize: '12px' }}
                          >
                            <i className="fa fa-edit"></i>
                          </button>
                          <button
                            onClick={() => handleDelete(item.id)}
                            className="btn btn-sm btn-danger"
                            style={{ fontSize: '12px' }}
                          >
                            <i className="fa fa-trash"></i>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Pagination */}
      {!loading && items.length > 0 && (
        <div className="d-flex justify-content-between align-items-center mt-3">
          <div style={{ fontSize: '14px', color: '#787878' }}>
            Mostrando {((pagination.currentPage - 1) * pagination.pageSize) + 1} - {Math.min(pagination.currentPage * pagination.pageSize, pagination.totalItems)} de {pagination.totalItems} resultados
          </div>
          <div>
            {/* TODO: Add Pagination component */}
            {/* <Pagination currentPage={pagination.currentPage} totalPages={...} onPageChange={...} /> */}
          </div>
        </div>
      )}
    </div>
  );
};

export default ENTITY_NAMEList;
